# from django import forms
# from .models import Students

# class StudentForm(forms.ModelForm):
#     class Meta:
#         model = Students
#         fields = ['sname', 'email', 'course', 'department', 'semester']  # Customize the fields as needed